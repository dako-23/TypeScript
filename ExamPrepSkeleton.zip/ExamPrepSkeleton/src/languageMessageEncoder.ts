export class LanguageMessageEncoder {}
